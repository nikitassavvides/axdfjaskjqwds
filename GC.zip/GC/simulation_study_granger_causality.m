%% ----------------------------------------------------------
% Simulation Study (Granger Causality: Linear and Nonlinear)
% -----------------------------------------------------------
clear; close all; clc; rng(1);

% Change the path so ALL the folders are included
addpath(genpath(pwd));

%% ----------------------------
% 1. Synthetic Data Generation
% -----------------------------

plot_flag = 0; 
results = struct();
k = 1;

% SAME SYNTHETIC DATA FOR PPP-GLM AND GC
factors = [5, 10, 20]; 
N = [4, 7, 9];

for factor = factors
    for n = N
        % load synthetic data files
        filename = sprintf('test_%d_nodes_factor_%d.mat', n, factor);
        try
            table_Y = load(filename);
            fieldNames = fieldnames(table_Y);
            Y = table_Y.(fieldNames{1}); 
        catch ME
            warning('There is not such a file: %s', filename);
            Y = [];
        end
        
        % ADJACENCY MATRIX (ground truth)
        switch n
            case 4
                Adjacency_matrix = zeros(4);
                Adjacency_matrix(1,2:4) = 1;
            case 7
                Adjacency_matrix = zeros(7);
                Adjacency_matrix(1,2:4) = 1;
                Adjacency_matrix(2,5)   = 1;
                Adjacency_matrix(3,5)   = 1;
                Adjacency_matrix(4,6)   = 1;
                Adjacency_matrix(5,7)   = 1;
                Adjacency_matrix(6,7)   = 1;
            case 9
                Adjacency_matrix = zeros(9);
                Adjacency_matrix(1,[3 4 5]) = 1;
                Adjacency_matrix(2,[5 6])   = 1;
                Adjacency_matrix(3,7)       = 1;
                Adjacency_matrix(4,7)       = 1;
                Adjacency_matrix(5,8)       = 1;
                Adjacency_matrix(6,8)       = 1;
                Adjacency_matrix(7,9)       = 1;
                Adjacency_matrix(8,9)       = 1;
                Adjacency_matrix(9,[1 2])   = 1;
            otherwise
                error('No ground-truth defined for N = %d', n);
        end
        
        %% ------------------------------------
        % 2. Smoothing the Binary Spike Trains
        % -------------------------------------
        dt = 0.004;             % time bin (4 ms)
        
        % Smoothing transforms the spike train into an instantaneous firing rate
        % estimate 
        
        % Gaussian kernel width in ms
        sigma_ms = 5;                  
        % it is long enough to smooth out single-spike variability
        % it is short enough to preserve temporal resolution for interactions
        % between neurons
        
        % convert ms to time bins
        sigma = sigma_ms / 1000 / dt;   
        % dividing by 1000 converts milliseconds to seconds 
        % dividing by dt = 0.004 converts seconds to number of time bins in your
        % discrete-time spike train 
        
        L = ceil(5*sigma);
        x = -L:L;
        % the kernel spans from -L to L 
        g = exp(-x.^2/(2*sigma^2));
        
        g = g / sum(g);
        % normalise so that total area = 1 (since we truncated)
        % ensures the smoothed firing rate has the same mean scale as original
        % spikes
        
        Y_smooth = zeros(size(Y));        
        for i = 1:n
            Y_smooth(i,:) = conv(Y(i,:), g, 'same') / dt;
        end
        % bin size is dt = 0.004s (4 ms)
        % dividing by dt converts the smoothed spike counts per bin to firing rate
        % in Hz 
        
        % conv: convolution spreads each spike across nearby bins, making the
        % signal smooth instead of spikes at exact points
        
        %% ---------------------------
        % 3. Linear Granger Causality
        % ----------------------------
        
        X = Y_smooth'; % input GC matrix
        
        maxLag_list = [10];   % number of past time points to include
        % Too small maxLag: you may miss slow causal effects; the model may underfit.
        % Too large maxLag: increases dimensionality → more parameters → overfitting, more variance, less reliable statistics.
        
        for maxLag = maxLag_list
        
            [GC_matrix, F_matrix, p_matrix, maxLag_optimal] = compute_linear_granger_causality(X, maxLag, plot_flag);
        
            %% ----------------------------------
            % 3. Evaluate performance metrics
            % -----------------------------------
            
            TP = sum((GC_matrix==1) & (Adjacency_matrix==1), 'all');
            FP = sum((GC_matrix==1) & (Adjacency_matrix==0), 'all');
            FN = sum((GC_matrix==0) & (Adjacency_matrix==1), 'all');
            TN = sum((GC_matrix==0) & (Adjacency_matrix==0), 'all');
            
            if TP + FP > 0
                precision = TP / (TP + FP);
            else
                precision = 0;
            end
            recall = TP / (TP + FN);
            accuracy  = (TP + TN) / (TP + TN + FP + FN);
            if precision + recall > 0
                F1 = 2 * (precision * recall) / (precision + recall);
            else
                F1 = 0;
            end
            results(k).maxLag    = maxLag_optimal;
            results(k).N         = n;
            results(k).factor    = factor;
            results(k).TP        = TP;
            results(k).FP        = FP;
            results(k).FN        = FN;
            results(k).TN        = TN;
            results(k).precision = precision;
            results(k).recall    = recall;
            results(k).accuracy  = accuracy;
            results(k).F1  = F1;

            %% Store results in struct 
            out = struct();
            out.GC_matrix        = GC_matrix;
            out.F_matrix         = F_matrix;
            out.p_matrix         = p_matrix;
            out.Adjacency_matrix = Adjacency_matrix;
            
            out.metrics.TP        = TP;
            out.metrics.FP        = FP;
            out.metrics.FN        = FN;
            out.metrics.TN        = TN;
            out.metrics.precision = precision;
            out.metrics.recall    = recall;
            out.metrics.accuracy  = accuracy;
            out.metrics.F1        = F1;
            
            out.params.N        = n;
            out.params.factor   = factor;
            out.params.maxLag   = maxLag_optimal;
            out.params.dt       = dt;
            out.params.sigma_ms = sigma_ms;
            
            %% Save results file
            save_filename = sprintf('Results/gc_N%d_factor%d_maxLag%d.mat', n, factor, maxLag);
            save(save_filename, 'out');
            fprintf('Saved: %s\n', save_filename);

            k = k + 1;
        end
    end
end

%% Print the results table

fprintf('\n N  factor  maxLag |  F1  | Precision | Recall | Accuracy\n');
fprintf('--------------------------------------------------------\n');

for i = 1:length(results)
    fprintf('%2d   %2d      %2d   |   %.2f |   %.2f    |  %.2f  |   %.2f\n', ...
        results(i).N, ...
        results(i).factor, ...
        results(i).maxLag, ...
        results(i).F1, ...
        results(i).precision, ...
        results(i).recall, ...
        results(i).accuracy);
end

%% ---------------------------
% 4. Figure: Spikes train
% ----------------------------
if plot_flag
    regions_to_plot = [1];   
    T = size(Y,2);
    time = (0:T-1) * dt; 
    t_start = 15;            
    t_end   = 20;
    idx = time >= t_start & time <= t_end;
    
    figure('Color','w','Position',[100 100 900 500]);
    
    for n = 1:length(regions_to_plot)
        i = regions_to_plot(n);
        subplot(length(regions_to_plot),2,2*n-1)
        spike_times = time(idx & Y(i,:) == 1);
        stem(spike_times, ones(size(spike_times)));
        xlabel('Time (s)');
        ylabel('Spikes');
        title(['Region ' num2str(i) ' – Spike train']);
        box off
        subplot(length(regions_to_plot),2,2*n);
        plot(time(idx), Y_smooth(i,idx));
        xlabel('Time (s)'); ylabel('Firing rate (Hz)');
        title(['Region ' num2str(i) ' – Smoothed spike train for the input GC']);
        box off
    end
end
