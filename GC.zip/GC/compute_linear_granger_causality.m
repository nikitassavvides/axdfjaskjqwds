%% Linear granger causality function

function [GC_matrix, F_matrix, p_matrix, p_opt] = compute_linear_granger_causality(X, maxLag, plot_flag)
% COMPUTE_GRANGER Compute pairwise Granger causality
% 
% Inputs:
%   X       - n_timepoints x n_channels matrix (rows = time, cols = channels)
%   maxLag  - number of past time points (VAR order) 
%   plot_flag - if true, plots the Granger causality matrix
%
% Outputs:
%   GC_matrix - binary matrix: 1 if significant Granger causality, 0 otherwise
%   F_matrix  - F-statistics for all pairs
%   p_matrix  - p-values for all pairs
%   p_opt     - significance threshold used to determine GC_matrix 

    [T, N] = size(X);
    if T <= 2
        error('Too few timepoints (T=%d). Need more data.', T);
    end

    %% Check stationarity
    isStat = false(1,N);
    for region = 1:N
        try
            [tstat, ~] = adf(X(:,region), 0, 0);
            isStat(region) = (tstat < -2.86); % approx 5% threshold
        catch
            isStat(region) = false;
        end
    end

    if any(~isStat)
        warning('Some regions appear non-stationary. VAR fitting may be invalid.');
    end

    %% Choose VAR order p: BIC metric
    Xv = X'; % N x T
    
    regmode = 'OLS';
    verb = false;
    
    [~, bic, ~, mobic] = tsdata_to_infocrit(Xv, maxLag, regmode, verb);
    %p_opt = moaic; % optimal p value
    %p_opt = bic;
    p_opt = mobic;  % optimal p value
    disp("p optimal");disp(p_opt);
    % Penalizes too large models (many parameters)
    % Penalizes too small models (poor fit)
    % The optimal p minimizes BIC.
    
    % Visualization
    lags = 1:maxLag;
    if plot_flag
        figure('Color','w','Position',[300 300 600 400])
        
        plot(lags, bic, '-o');
        hold on
        
        xline(p_opt, '--r', ...
              'Label', sprintf('Selected p = %d (BIC)', p_opt), ...
              'LabelOrientation', 'horizontal')
        
        xlabel('VAR order (lag)')
        ylabel('BIC')
        title('BIC vs VAR order','FontSize',10,'FontWeight','bold')
        
        grid on
        box off
    end
    %% Estimate VAR model
    try
        [A, SIG] = tsdata_to_var(Xv, p_opt, 'OLS');
        % A = VAR coefficient matrices, size N×N×p
        % SIG = residual covariance matrix, size N×N
    catch ME
        error('VAR model estimation failed: %s', ME.message);
    end
    %% Check stability 
    try % ensures all eigenvalues of the VAR
        [n,~,p] = size(A);
        A1 = [reshape(A,n,n*p); eye(n*(p-1)), zeros(n*(p-1),n)];
        
        % Spectral radius
        rho = max(abs(eig(A1)));
        
        if rho >= 1
            warning('VAR model is unstable: spectral radius = %f', rho);
        else
            disp('VAR model is stable');
        end
    catch ME
        error('Stability check failed: %s', ME.message);
    end
    
    %% Granger F-statistic matrix and p-values
    try
        F_matrix = zeros(N,N);
        p_matrix = zeros(N,N);
        
        for i = 1:N
            for j = 1:N
                if i == j % NO make sense self-coupling
                    F_matrix(i,j) = 0;
                    p_matrix(i,j) = 0;
                    continue;
                end
                % We want: i → j
                % var_to_mvgc(A,SIG,x,y) computes: y → x
                x = i;    % target
                y = j;    % source
                [F_matrix(i,j), p_matrix(i,j)] = var_to_mvgc(A, SIG, y, x, Xv, 'OLS', 'F');
            end
        end
    catch ME
        error('Error computing Granger causality F-statistics: %s', ME.message);
    end   
    % 1 = significant Granger causality
    % 0 = not significant
    alpha = 0.05;
    GC_matrix = (p_matrix < alpha) & ~eye(N); % Avoid to count self-coupling as significant
    % Assuming a significance level of 0.05, if the p-value is lesser than 0.05, 
    % then we do NOT reject the null hypothesis that X does NOT granger cause Y
end