clear; close all; clc;
resultsPath = 'Results';
files = dir(fullfile(resultsPath,'gc_N*_factor*_maxLag10.mat'));
figFolder = 'Figures';
if ~exist(figFolder, 'dir')
    mkdir(figFolder)
end

%% NETWORK visualization (Ground truth vs GC)

for f = 1:length(files)
    filePath = fullfile(files(f).folder, files(f).name);
    table_out = load(filePath);
    out = table_out.out;
    
    GC_matrix        = out.GC_matrix;
    Adjacency_matrix = out.Adjacency_matrix;
    p_matrix         = out.p_matrix;
    n                = out.params.N;
    S                = out.params.factor;
    
    G_true = digraph(Adjacency_matrix);
    G_gc   = digraph(GC_matrix);
    
    % Clockwise circle starting from left
    theta = linspace(pi, -pi + 2*pi/n, n);
    radius = 1;
    x_circle = radius * cos(theta);
    y_circle = radius * sin(theta);
    
    figure('Color','w','Position',[100 100 800 400]); 
    tiledlayout(1,2,'Padding','compact','TileSpacing','compact')
    
    labels = compose("R%d", 1:n);
    
    %% ---------- Ground Truth ----------
    nexttile
    h1 = plot(G_true, ...
        'XData', x_circle, 'YData', y_circle, ...
        'NodeLabel', {}, 'LineWidth', 2, 'ArrowSize', 12);
    title(sprintf('Ground Truth (N=%d)', n), ...
          'FontSize',10, 'FontWeight','bold')
    axis off; hold on
    for i = 1:n
        text(1.12*h1.XData(i), 1.12*h1.YData(i), labels(i), ...
            'FontSize',11,'FontWeight','bold','HorizontalAlignment','center');
    end
    
    %% ---------- GC Network ----------
    nexttile
    h2 = plot(G_gc, 'XData', x_circle, 'YData', y_circle, ...
        'NodeLabel', {}, 'LineWidth', 2, 'ArrowSize', 12);
    title(sprintf('Granger Causality Inferred Network (S=%d)', S),'FontSize',10,'FontWeight','bold')
    axis off; hold on
    
    % Edge thickness 
    weights = -log10(p_matrix);
    finiteWeights = weights(~isinf(weights));
    if isempty(finiteWeights)
        weights(:) = 1;
    else
        weights(isinf(weights)) = max(finiteWeights);
    end
    edge_weights = zeros(numedges(G_gc),1);
    for e = 1:numedges(G_gc)
        i = G_gc.Edges.EndNodes(e,1);
        j = G_gc.Edges.EndNodes(e,2);
        edge_weights(e) = weights(i,j);
    end
    if max(edge_weights) == min(edge_weights)
        scaled_widths = ones(size(edge_weights)) * 2; % default thickness
    else
        % Scale thickness for visualization
        minWidth = 1; maxWidth = 5;
        scaled_widths = minWidth + (edge_weights - min(edge_weights)) / ...
                        (max(edge_weights)-min(edge_weights)) * (maxWidth - minWidth);
    end

    h2.LineWidth = scaled_widths; 
    
    % Edge colors
    edgeColors = zeros(numedges(G_gc),3);
    for e = 1:numedges(G_gc)
        i = G_gc.Edges.EndNodes(e,1);
        j = G_gc.Edges.EndNodes(e,2);
        if Adjacency_matrix(i,j) == 1
            edgeColors(e,:) = [0.2 0.7 0.2];   % TP
        else
            edgeColors(e,:) = [0.85 0.2 0.2];  % FP
        end
    end
    h2.EdgeColor = edgeColors;
    
    % False negatives
    for i = 1:n
        for j = 1:n
            if i ~= j && Adjacency_matrix(i,j) == 1 && GC_matrix(i,j) == 0
                plot([x_circle(i) x_circle(j)], [y_circle(i) y_circle(j)], ...
                     '--','Color',[0.5 0.5 0.5],'LineWidth',1.5);
            end
        end
    end
    
    % Node labels
    for i = 1:n
        text(1.12*h2.XData(i), 1.12*h2.YData(i), labels(i), ...
            'FontSize',11,'FontWeight','bold','HorizontalAlignment','center');
    end
    
    % Legend
    lgd = legend([ ...
        plot(nan,nan,'-','Color',[0.2 0.7 0.2],'LineWidth',2), ...
        plot(nan,nan,'-','Color',[0.85 0.2 0.2],'LineWidth',2), ...
        plot(nan,nan,'--','Color',[0.5 0.5 0.5],'LineWidth',2)], ...
        {'TP','FP','FN'}, 'Location','southoutside','Orientation','horizontal');
    lgd.Box = 'off';
    [~, name, ~] = fileparts(files(f).name); 
    savePath = fullfile(figFolder, [name '.png']); 
    exportgraphics(gcf, savePath);
    close(gcf);
end

%% Figure: Sparse vs FP

density_labels = {'Low', 'Medium', 'High'};
maxLag = 10;
resultsPath = 'Results';
files = dir(fullfile(resultsPath,'gc_N*_factor*_maxLag10.mat'));

FP_GC_low = [];
FP_GC_mid = [];
FP_GC_high = [];

FP_PPP_low = [];
FP_PPP_mid = [];
FP_PPP_high = [];

for f = 1:length(files)

    S = load(fullfile(files(f).folder, files(f).name));
    out = S.out;

    FP_GC = out.metrics.FP;
    density  = out.params.factor;  

    % Density (higher factor = lower density)
    switch density
        case 20   % High density (low sparsity)
            FP_GC_low(end+1) = FP_GC;
        case 10   % Medium density
            FP_GC_mid(end+1) = FP_GC;
        case 5    % High density (high sparsity)
            FP_GC_high(end+1) = FP_GC;
    end
end
FP_GC = [
    mean(FP_GC_low), ...
    mean(FP_GC_mid), ...
    mean(FP_GC_high)
];
FP_PPP_low  = [0 3 3];     
FP_PPP_mid  = [0 0 0];    
FP_PPP_high = [0 0 0];
FP_PPP = [
    mean(FP_PPP_low), ...
    mean(FP_PPP_mid), ...
    mean(FP_PPP_high)
];

FP_matrix = [FP_GC; FP_PPP]';
b = bar(FP_matrix,'grouped');
hold on;

% Colors
b(1).FaceColor = [1 0.6 0.6];   % GC (light red)
b(2).FaceColor = [0.6 0.8 1];   % PPP (light blue)

set(gca,'XTickLabel',density_labels,'FontSize',9)

xlabel('Network density','FontSize',10);
ylabel('Number of false positives','FontSize',10);
title('False positives vs network density (maxLag = 10)','FontSize',11);

legend({'Granger causality','PPP-GLM'}, 'Location','northwest');

grid on; box on;
